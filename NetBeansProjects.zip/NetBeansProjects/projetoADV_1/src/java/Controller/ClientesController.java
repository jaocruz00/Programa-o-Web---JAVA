
package Controller;

import DAO.ClientesDAO;
import VO.Cliente;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ClientesController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int operacao = Integer.parseInt(request.getParameter("op"));

        ClientesDAO dao = new ClientesDAO();

        switch (operacao) {

            case 1 -> {

                Cliente c = new Cliente();

                c.setNome(request.getParameter("nome"));
                c.setCpf(request.getParameter("cpf"));
                c.setRg(request.getParameter("rg"));
                c.setSenhaGov(request.getParameter("senhaGov"));
                c.setCnh(request.getParameter("cnh"));
                c.setIdade(Integer.parseInt(request.getParameter("idade")));
                c.setEndereco(request.getParameter("endereco"));
                c.setTelefone(request.getParameter("telefone"));
                c.setCasoProcesso(request.getParameter("casoProcesso"));

                response.sendRedirect("resultado_cliente.jsp?result=" + dao.inserir(c));
            }

            case 2 -> {

                request.setAttribute("lista", dao.listar());

                RequestDispatcher rd = request.getRequestDispatcher("/listar_clientes.jsp");

                rd.forward(request, response);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        processRequest(request, response);
    }
}
