package DAO;

import Conexao.Conexao;
import VO.Checklist;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ChecklistDAO {

    private final Conexao conexao;

    public ChecklistDAO() {
        conexao = new Conexao();
    }

    public boolean inserir(Checklist c) {

        try {

            String sql =
            "insert into checklist_cliente "
            + "(cpf_cliente, documento, status) "
            + "values (?,?,?)";

            PreparedStatement ps =
            conexao.conectar().prepareStatement(sql);

            ps.setString(1, c.getCpfCliente());
            ps.setString(2, c.getDocumento());
            ps.setBoolean(3, c.isStatus());

            return ps.executeUpdate() != 0;

        } catch (Exception e) {

            return false;

        } finally {

            conexao.desconectar();
        }
    }

    public boolean alterarStatus(int id, boolean status){

        try{

            String sql =
            "update checklist_cliente "
            + "set status=? "
            + "where id=?";

            PreparedStatement ps =
            conexao.conectar().prepareStatement(sql);

            ps.setBoolean(1,status);
            ps.setInt(2,id);

            return ps.executeUpdate()!=0;

        }catch(Exception e){

            return false;

        }finally{

            conexao.desconectar();
        }
    }

}