package DAO;

import Conexao.Conexao;
import VO.Pessoa;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PessoasDAO {
    private final Conexao conexao;

    public PessoasDAO() {
        conexao = new Conexao();
    }

    public boolean inserir(Pessoa p) {
        try {
            PreparedStatement ps;
            String sql = "insert into pessoa (cpf,nome) values (?,?)";
            ps = conexao.conectar().prepareStatement(sql);
            ps.setString(1, p.getCpf());
            ps.setString(2, p.getNome());
            return ps.executeUpdate() != 0;
        } catch (SQLException erro) {
            System.out.println("Exceção causada na inserção");
            return false;
        } finally {
            conexao.desconectar();
        }
    }

    public ArrayList<Pessoa> listar() {
        PreparedStatement ps; // estrutura o sql
        ResultSet rs; //armazenará o resultado do bd
        try {
            String sql = "select cpf,nome from pessoa";
            ps = conexao.conectar().prepareStatement(sql);
            rs = ps.executeQuery(); // executa o sql no banco e retorna o resultado
            ArrayList<Pessoa> lista = new ArrayList<>();            
            while (rs.next()) {
                Pessoa p = new Pessoa();
                //setar os valores dentro de um objeto (Pessoa)
                //adicionar este objeto a uma list
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("cpf"));
                lista.add(p);
            }
            return lista;
        } catch (SQLException erro) {
            System.err.print("Exceção gerada ao tentar buscar os dados: " + erro.getMessage());
            return null;
        } finally {
            conexao.desconectar();
        }
    }
}
