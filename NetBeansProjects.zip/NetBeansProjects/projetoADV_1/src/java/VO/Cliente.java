
package VO;

public class Cliente {
    private String nome;
    private String cpf;
    private String rg;
    private String senhaGov;
    private String cnh;
    private int idade;
    private String endereco;
    private String telefone;
    private String casoProcesso;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getSenhaGov() {
        return senhaGov;
    }

    public void setSenhaGov(String senhaGov) {
        this.senhaGov = senhaGov;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCasoProcesso() {
        return casoProcesso;
    }

    public void setCasoProcesso(String casoProcesso) {
        this.casoProcesso = casoProcesso;
    }
}
