import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexao {


    private String bd;
    private String usuario;
    private String senha;

public Conexao () {

    bd = "cd";
    usuario = "root";
    senha = "";
    
}public void conectar () {

    Connection con;

    try {

        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost/" + bd, usuario, senha);
        JOptionPane.showMessageDialog(null, "Sucesso");
       // con.close();a
        }catch (ClassNotFoundException | SQLException erro) {
            System.out.println("Erro na conexão: " + erro);
    }
  }
public static void main(String args []){
    Conexao c = new Conexao();
    c.conectar();
}
}