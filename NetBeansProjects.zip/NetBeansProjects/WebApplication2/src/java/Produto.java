/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joaov
 */
public class Produto {
   
    private int id;
    private String nome;
    private doule valor;
    private int quantidade;
    
}
