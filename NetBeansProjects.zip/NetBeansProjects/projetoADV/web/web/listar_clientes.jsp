
<%@page import="java.util.List"%>
<%@page import="VO.Cliente"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>

<html>
<head>
    <meta charset="UTF-8">
    <title>Clientes</title>
</head>

<body>

<center>

<h1>Clientes Cadastrados</h1>

<%

List clientes = (List) request.getAttribute("lista");

if(clientes != null){

    out.print("<table border='1' width='90%'>");

    out.print("<tr>");
    out.print("<th>Nome</th>");
    out.print("<th>CPF</th>");
    out.print("<th>Telefone</th>");
    out.print("<th>Caso</th>");
    out.print("</tr>");

    for(int i = 0; i < clientes.size(); i++){

        Cliente c = (Cliente) clientes.get(i);

        out.print("<tr>");
        out.print("<td>" + c.getNome() + "</td>");
        out.print("<td>" + c.getCpf() + "</td>");
        out.print("<td>" + c.getTelefone() + "</td>");
        out.print("<td>" + c.getCasoProcesso() + "</td>");
        out.print("</tr>");
    }

    out.print("</table>");
}

%>

<br><br>

<a href="index.html">Página Inicial</a>

</center>

</body>
</html>
