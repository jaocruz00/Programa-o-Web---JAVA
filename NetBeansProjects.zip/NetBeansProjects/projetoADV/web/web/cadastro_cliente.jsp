
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>

<html>
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Cliente</title>
</head>

<body>

<center>
    <h1>Cadastro de Cliente - Escritório de Advocacia</h1>

    <form method="post" action="ClientesController?op=1">

        Nome: <input type="text" name="nome"><br><br>

        CPF: <input type="text" name="cpf"><br><br>

        RG: <input type="text" name="rg"><br><br>

        Senha GOV: <input type="text" name="senhaGov"><br><br>

        CNH: <input type="text" name="cnh"><br><br>

        Idade: <input type="number" name="idade"><br><br>

        Endereço: <input type="text" name="endereco"><br><br>

        Telefone: <input type="text" name="telefone"><br><br>

        Caso do Processo:<br>
        <textarea name="casoProcesso" rows="5" cols="40"></textarea><br><br>

        <input type="submit" value="Cadastrar Cliente">

    </form>

</center>

</body>
</html>
