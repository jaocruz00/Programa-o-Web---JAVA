
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>

<html>
<head>
    <meta charset="UTF-8">
    <title>Resultado</title>
</head>

<body>

<center>

<h1>

<%

boolean resultado = Boolean.parseBoolean(request.getParameter("result"));

if(resultado){
    out.print("Cliente cadastrado com sucesso!");
}else{
    out.print("Erro ao cadastrar cliente!");
}

%>

</h1>

<br><br>

<a href="index.html">Voltar</a>

</center>

</body>
</html>
