<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Inserir Cliente</title>
    </head>
    <body>
    <center>
        <h2>Cadastrar Cliente</h2>
        <form name="frm" method="post" action="PessoasController?op=1">
            Nome: <input type="text" name="nome" required> 
            <br><br>
            CPF: <input type="text" name="cpf" required> 
            <br><br>
            Telefone: <input type="text" name="telefone" required> 
            <br><br>
            E-mail: <input type="email" name="email" required> 
            <br><br>
            <input type="submit" value="Cadastrar">            
        </form>
        <br><br>
        <a href="index.html">Página inicial</a>
    </center>
    </body>
</html>