<%@page import="VO.Pessoa"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Editar Cliente</title>
    </head>
    <body>
    <center>
        <h2>Conferência e Edição de Dados</h2>
        <%
            Pessoa p = (Pessoa) request.getAttribute("pessoa");
            if (p != null) {
        %>
        <form name="frm" method="post" action="PessoasController?op=5">
            CPF: <input type="text" name="cpf" value="<%= p.getCpf() %>" readonly>
            <br><br>
            Nome: <input type="text" name="nome" value="<%= p.getNome() %>" required> 
            <br><br>
            Telefone: <input type="text" name="telefone" value="<%= p.getTelefone() %>" required> 
            <br><br>
            E-mail: <input type="email" name="email" value="<%= p.getEmail() %>" required> 
            <br><br>
            <input type="submit" value="Salvar Alterações">            
        </form>
        <% 
            } else {
                out.print("Erro: Nenhum dado de cliente foi carregado.");
            }
        %>
        <br><br>
        <a href="PessoasController?op=2">Voltar para listagem</a>
    </center>
    </body>
</html>