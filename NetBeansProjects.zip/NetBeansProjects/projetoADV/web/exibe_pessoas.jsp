<%@page import="java.util.List"%>
<%@page import="VO.Pessoa"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Listagem de Clientes</title>
    </head>
    <body>
        <center><h2>Clientes no Banco de Dados</h2></center>
        <%
            List pessoas = (List) request.getAttribute("lista");
            if (pessoas != null) {
                out.print("<center>Registros achados: " + pessoas.size() + "</center><br><br>");
                out.print("<table width=\"70%\" border=\"1\" cellspacing=\"0\" align=\"center\">");
                
                // Cabeçalho da tabela
                out.print("<tr bgcolor=\"#eeeeee\">");
                out.print("<th>CPF</th><th>Nome</th><th>Telefone</th><th>E-mail</th><th>Ações</th>");
                out.print("</tr>");
                
                for (int cont = 0; cont < pessoas.size(); cont++) {
                    Pessoa p = (Pessoa) pessoas.get(cont);
                    out.print("<tr>");
                    out.print("<td>" + p.getCpf() + "</td>");
                    out.print("<td>" + p.getNome() + "</td>");                    
                    out.print("<td>" + p.getTelefone() + "</td>");                    
                    out.print("<td>" + p.getEmail() + "</td>");                    
                    out.print("<td align=\"center\">");
                    // Links para as novas operações do CRUD
                    out.print("<a href=\"PessoasController?op=4&cpf=" + p.getCpf() + "\">Editar</a> | ");
                    out.print("<a href=\"PessoasController?op=3&cpf=" + p.getCpf() + "\" onclick=\"return confirm('Deseja excluir este cliente?')\">Excluir</a>");
                    out.print("</td>");
                    out.print("</tr>");
                }
                out.print("</table>");
            }            
        %>
        
        <br><br><br>
    <center><a href="index.html">Página inicial</a></center>
    </body>
</html>