<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Resultado da Operação</title>
    </head>
    <body>
    <center>
        <h1>
            <%
                boolean resultado = Boolean.parseBoolean(request.getParameter("result"));
                String acao = request.getParameter("msg"); // Captura qual foi a operação executada
                
                if (acao == null) {
                    acao = "processar dados";
                }

                if (resultado) {
                    out.print("Sucesso ao " + acao);
                } else {
                    out.print("Erro ao " + acao);
                }
            %>
        </h1>

        <br><br><br>
        <a href="PessoasController?op=2">Ver listagem atualizada</a> | 
        <a href="index.html">Página inicial</a>
    </center>
</body>
</html>